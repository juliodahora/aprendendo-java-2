package br.com.juliocesar;

public class PrimeiraClasse {
    public static void main (String args[]){
        System.out.println("HelloWorld");
    }
}
